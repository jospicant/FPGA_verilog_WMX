### Info: https://groups.google.com/g/fpga-wars-explorando-el-lado-libre/c/LEs77wvxBZg/m/jCcoumwjAwAJ
